from rdflib import Graph

if __name__ == '__main__':
	## go through the local host to get the relevent information needed for each query
	g = Graph()
	g.parse('http://localhost:8085/weather-2.html', format='rdfa')

	## Query 1 Forecast for the rest of the day in NSW & ACT 
	query1 = g.query("""SELECT ?obj
                    WHERE {<http://localhost:8085/weather-2.html> foaf:StateWeather ?obj . }
                    """) 
	
	print("QUERY 1:")
	print("Find the forecast for the rest of the day in NSW and ACT on the 26th of April")
	print()
	for x in query1:
		print(x.obj)
	print()
		
	## Query 2 Min and Max Temp in Canberra on the 28th	
	query2 = g.query("""SELECT ?obj1 ?obj2 ?obj3
                    WHERE {<http://localhost:8085/weather-2.html> foaf:Canberrahead ?obj1 .
                    	   <http://localhost:8085/weather-2.html> foaf:Can28April ?obj2 .
                    	   <http://localhost:8085/weather-2.html> foaf:Can28MinMax ?obj3 . }
                    """)
    
	print("QUERY 2:")
	print("Find the Minumum and Maximum Temperature in Canberra on the 28th of April")
	print()
	for x in query2:
		print(x.obj1, x.obj2, x.obj3)
	print()
	
	## Query 3 the locations in the Snowy Mountain
	query3 = g.query("""SELECT ?obj
                    WHERE {<http://localhost:8085/weather-2.html> foaf:SnowyMountLocation ?obj . }
                    """)
    
	print("QUERY 3:")
	print("Find all locations in the Snowy Mountain District")
	print()
	for x in query3:
		print(x.obj)
	print()
	
	## Query 4 the forecast in Sydney on the 29th of April
	query4 = g.query("""SELECT ?obj1 ?obj2 ?obj3 
                    WHERE {<http://localhost:8085/weather-2.html> foaf:Syd29April ?obj1 .
                    	   <http://localhost:8085/weather-2.html> foaf:SydForecast ?obj2 .
                    	   <http://localhost:8085/weather-2.html> foaf:SydTemp ?obj3 . }
                    """)
    
	print("QUERY 4:")
	print("Show the forecast for the 29 April in Sydney")
	print()
	for x in query4:
		print(x.obj1, x.obj2, x.obj3)
	print()
	
	
	
	
	
	
	
	
	
	